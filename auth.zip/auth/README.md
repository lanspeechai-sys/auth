# Week 2 - Activity 1 (Authentication Setup) — Part 1

This repo implements **Part 1** of the lab in PHP (MVC-style), with:
- Customer model & controller for registration
- Fully validated registration form (client + server)
- Async submission via JS
- Minimal index and placeholder login

Per lab note, **Image** is `NULL` by default and **User role** is set via DB default (2 = customer), so they are **not collected at sign-up**.

## Project Structure
```
config/
  db.php
classes/
  customer_class.php
controllers/
  customer_controller.php
actions/
  register_customer_action.php
public/
  index.php
  login.php
  register.php
  assets/
    css/styles.css
    js/register.js
```

## Quick Start
1. Create a MySQL database (default name `ecomm_lab` or edit `config/db.php`).
2. Ensure PHP has PDO MySQL enabled.
3. Place the project in your web root so that `/public` is web-accessible. Example:
   - Apache: `DocumentRoot /path/to/project/public`
   - PHP built-in server (for local testing): `php -S localhost:8080 -t public`
4. Open `http://localhost:8080/register.php` and register a new user.

> The first request will auto-create the `customers` table if it does not exist.

## Customers Table DDL
```sql
CREATE TABLE IF NOT EXISTS customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  country VARCHAR(60) NOT NULL,
  city VARCHAR(60) NOT NULL,
  contact_number VARCHAR(30) NOT NULL,
  image VARCHAR(255) DEFAULT NULL,
  user_role TINYINT NOT NULL DEFAULT 2, -- 1=admin, 2=customer
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## Notes
- Passwords are hashed using `password_hash()` with BCRYPT.
- Email uniqueness is enforced in SQL and also checked in PHP.
- Frontend validation uses regex and length checks (matching DB column sizes).
- On success, users are redirected to `login.php` (placeholder for now).
- Keep your credentials in `config/db.php` in sync with your local DB.
```